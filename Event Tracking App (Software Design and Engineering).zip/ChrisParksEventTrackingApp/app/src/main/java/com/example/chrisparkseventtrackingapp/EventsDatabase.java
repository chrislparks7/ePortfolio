package com.example.chrisparkseventtrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class EventsDatabase extends SQLiteOpenHelper {

    // Variable to create database
    private static final String DATABASE_NAME = "events.db";
    private static final int VERSION = 1;
    private final Context context;
    SQLiteDatabase db;
    private static final String DATABASE_PATH = "/data/data/com.example.chrisparkseventtrackingapp/databases/";
    private String outFileName;
    private static final String TAG = MainActivity.class.getName();

    // Database constructor
    public EventsDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
        createDb();
    }

    // Sets up the columns for the table
    private static final class EventsTable {
        private static final String TABLE = "events";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_DATE = "date";
        private static final String COL_TIME = "time";
        private static final String COL_DESCRIPTION = "description";
    }

    // Creates the event database
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + EventsTable.TABLE + " (" +
                EventsTable.COL_ID + " integer primary key autoincrement, " +
                EventsTable.COL_NAME + " text, " +
                EventsTable.COL_DATE + " date, " +
                EventsTable.COL_TIME + " time, " +
                EventsTable.COL_DESCRIPTION + " text)");
    }

    // Checks for the most recent version of database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + EventsTable.TABLE);
        onCreate(db);
    }

    // Checks if database already exists and create database if not
    public void createDb() {
        boolean dbExist = checkDbExist();

        if(!dbExist) {
            this.getReadableDatabase();
            copyDatabase();
        }
    }

    // Database checker constructor
    private boolean checkDbExist () {
        SQLiteDatabase sqLiteDatabase = null;

        try {
            String path = DATABASE_PATH + DATABASE_NAME;
            sqLiteDatabase = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY);
        } catch (Exception ex) {

        }

        if(sqLiteDatabase != null) {
            sqLiteDatabase.close();
            return true;
        }

        return false;
    }

    // Adds events from the Add Event screen
    public long addEvent(String name, Long date, String time, String description) {

        long eventId = 0;

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(EventsTable.COL_NAME, name);
        values.put(EventsTable.COL_DATE, date);
        values.put(EventsTable.COL_TIME, time);
        values.put(EventsTable.COL_DESCRIPTION, description);

        eventId = db.insert(EventsTable.TABLE, null, values);
        return eventId;
    }

    // Copies the database in order to load database properly
    private void copyDatabase() {
        try {
            InputStream inputStream = context.getAssets().open(DATABASE_NAME);

            String outFile = DATABASE_PATH + DATABASE_NAME;

            OutputStream outputStream = new FileOutputStream(outFileName);

            byte[] b = new byte[1024];
            int length;

            while((length = inputStream.read(b)) > 0) {
                outputStream.write(b, 0, length);
            }

            // Close and flush the streams.  Good clean-up practices.
            outputStream.flush();
            outputStream.close();
            inputStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Opens the database
    private SQLiteDatabase openDatabase() {
        String path = DATABASE_PATH + DATABASE_NAME;
        db = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READWRITE);
        return db;
    }

    // Closes the database
    public void close() {
        if(db != null) {
            db.close();
        }
    }

    // Gets the events from the database and returns them from the cursor
    public Cursor getEvents() {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + EventsTable.TABLE;
        Cursor cursor = db.rawQuery(sql, new String[] {});
        if (cursor.moveToFirst()) {
          return cursor;
        } else {
            cursor.close();
            return null;
        }

    }


}
