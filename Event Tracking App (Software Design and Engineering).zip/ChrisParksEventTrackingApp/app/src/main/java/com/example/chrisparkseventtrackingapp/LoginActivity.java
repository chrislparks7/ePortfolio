package com.example.chrisparkseventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    // Variables for fields on screen
    Button loginButton;
    Button registerButton;
    EditText usernameEdit;
    EditText passwordEdit;
    DatabaseHelper databaseHelper;

    // Initiation instructions upon login screen start
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Set the buttons on the screen
        loginButton = (Button) findViewById(R.id.loginButton);
        registerButton = (Button) findViewById(R.id.registerButton);
        usernameEdit = (EditText) findViewById(R.id.usernameEdit);
        passwordEdit = (EditText) findViewById(R.id.passwordEdit);

        // Creates the database for the login information
        databaseHelper = new DatabaseHelper(LoginActivity.this);

        // Listens for the login button to be clicked
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Checks for user in database
                boolean isExist = databaseHelper.checkUserExist(usernameEdit.getText().toString(), passwordEdit.getText().toString());

                // If user exists in database, the app moves to the main activity.  If not, an error Toast message is displayed.
                if(isExist){
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                } else {
                    passwordEdit.setText(null);
                    Toast.makeText(LoginActivity.this, "Login failed. Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Listens for the register button to be clicked
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             // Pulls data from screen to variables
             String username = usernameEdit.getText().toString();
             String password = passwordEdit.getText().toString();

             // Loads variable to database
             long addLogin = databaseHelper.addUser(username, password);

             // Checks if registration was successful and displays results in Toast pop-up
             if(addLogin > 0) {
                 Toast.makeText(LoginActivity.this, "Username and password registered", Toast.LENGTH_SHORT).show();
             } else {
                 Toast.makeText(LoginActivity.this, "Username and password was not registered.  Try again.", Toast.LENGTH_SHORT).show();
             }

            }
        });
    }
}