package com.example.chrisparkseventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Class variables
    Button addButton;
    private ListView EventsList;
    EventsDatabase eventsDatabase;
    TextView nameText;
    TextView dateDisp;
    TextView timeDisp;

    // Initiation instructions upon main screen start
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Builds the buttons on main screen
        addButton = (Button) findViewById(R.id.addButton);
        nameText = (TextView) findViewById(R.id.nameText);
        dateDisp = (TextView) findViewById(R.id.dateDisp);
        timeDisp = (TextView) findViewById(R.id.timeDisp);
        eventsDatabase = new EventsDatabase(MainActivity.this);

        // Listening for user to click add event button
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddEventActivity.class);
                startActivity(intent);
            }
        });

    }

    // Option menu constructor
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return true;

    }

    // Resumes main screen on app resume
    @Override
    protected void onResume()
    {
        super.onResume();
    }

    // Option menu selector
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;

        switch (item.getItemId()) {
            case R.id.action_settings:
                // Settings selected
                intent = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(intent);
                return true;

            case R.id.action_about:
                // About selected
                intent = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // Pull the data from database and display it on the screen
    private void displayData(Intent intent) {
        // Cursor c = EventsDatabase.getEvents();
    }


}

