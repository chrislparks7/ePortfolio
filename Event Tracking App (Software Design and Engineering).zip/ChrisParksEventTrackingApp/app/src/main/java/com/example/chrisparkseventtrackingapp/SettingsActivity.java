package com.example.chrisparkseventtrackingapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class SettingsActivity extends AppCompatActivity {

    // Variables for buttons
    Button okSetButton;
    Button enableButton;

    // Variables to allow program to check for permissions
    private static final String TAG = MainActivity.class.getName();
    public static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 100;

    // Initiation instructions upon settings menu opening
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);

        // Set buttons on menu
        okSetButton = (Button) findViewById(R.id.okSetButton);
        enableButton = (Button) findViewById(R.id.enableButton);

        // Listening for ok button to be clicked
        okSetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Returns user to main screen
                Intent intent = new Intent(SettingsActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Listening for enable SMS button to be clicked
        enableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkForSmsPermission();
            }
        });

    }

    // Constructor to check for permissions
    private void checkForSmsPermission() {
        // Checks if permissions are already granted or not
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, getString(R.string.permission_not_granted));
            // This will pop-up the request to ask for permissions
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    MY_PERMISSIONS_REQUEST_SEND_SMS);
        } else {
            // Permission already granted.
        }
    }
}