#!/usr/bin/env python
#
# GrovePi Example for using the Grove Temperature & Humidity Sensor Pro 
# (http://www.seeedstudio.com/wiki/Grove_-_Temperature_and_Humidity_Sensor_Pro)
#
# The GrovePi connects the Raspberry Pi and Grove sensors.  
# You can learn more about GrovePi here:  http://www.dexterindustries.com/GrovePi
#
# Have a question about this example?  Ask on the forums here:  http://forum.dexterindustries.com/c/grovepi
#
'''
## License
The MIT License (MIT)
GrovePi for the Raspberry Pi: an open source platform for connecting Grove Sensors to the Raspberry Pi.
Copyright (C) 2017  Dexter Industries
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
'''
import grovepi
import math
import json
import grove_rgb_lcd
import time
from datetime import datetime
# Connect the Grove Temperature & Humidity Sensor Pro to digital port D7
# This example uses the blue colored sensor.
# SIG,NC,VCC,GND
sensor = 7  # The Sensor goes on digital port 7.

# temp_humidity_sensor_type
# Grove Base Kit comes with the blue sensor.
blue = 0    # The Blue colored sensor.
white = 1   # The White colored sensor.

# Connect the Grove Light Sensor to analog port A0
# SIG,NC,VCC,GND
light_sensor = 0

# Connect the red LED to digital port D2
# SIG,NC,VCC,GND
red_led = 2

# Connect the blue LED to digital port D3
# SIG,NC,VCC,GND
blue_led = 3

# Connect the green LED to digital port D4
# SIG,NC,VCC,GND
green_led = 4

# Stop function if threshold is exceeded
threshold = 1000

grovepi.pinMode(light_sensor,"INPUT")
grovepi.pinMode(red_led,"OUTPUT")
grovepi.pinMode(blue_led,"OUTPUT")
grovepi.pinMode(green_led,"OUTPUT")

# Set blue as backlight color
# Reduces the amount of data transfer over the I2C line
grove_rgb_lcd.setRGB(0,0,255)


while True:
    try:
        current_time = datetime.now().strftime("%m.%d.%Y, %H:%M:%S")
        
        # Get sensor value
        sensor_value = grovepi.analogRead(light_sensor)

        # Calculate resistance of sensor in K
        resistance = (float)(1023 - sensor_value) * 10 / sensor_value

        # This example uses the blue colored sensor. 
        # The first parameter is the port, the second parameter is the type of sensor.
        [temp,humidity] = grovepi.dht(sensor,blue)
        
        # Change temp reading from celsius to fahrenheit
        temp = ((temp/5.0)*9)+32
        
        # Round the temperature to 2 decimal places
        temp = round(temp, 2)

        if math.isnan(temp) == False and math.isnan(humidity) == False:
            print("temp = %.02f F\humidity =%.02f%%" %(temp, humidity))
        
        # LED light controls
        if temp > 60 and temp < 85 and humidity < 80:
            # Send HIGH to switch on green LED
            grovepi.digitalWrite(green_led,1)
            # Send LOW to turn off all other LEDs
            grovepi.digitalWrite(blue_led,0)
            grovepi.digitalWrite(red_led,0)
        elif temp > 85 and temp < 95 and humidity < 80:
            # Send HIGH to switch on blue LED
            grovepi.digitalWrite(blue_led,1)
            # Send LOW to turn off all other LEDs
            grovepi.digitalWrite(green_led,0)
            grovepi.digitalWrite(red_led,0)
        elif temp > 95:
            # Send HIGH to switch on red LED
            grovepi.digitalWrite(red_led,1)
            # Send LOW to turn off all other LEDs
            grovepi.digitalWrite(green_led,0)
            grovepi.digitalWrite(blue_led,0)
        elif humidity > 80:
            # Send HIGH to switch on blue LED
            grovepi.digitalWrite(blue_led,1)
            # Send HIGH to switch on green LED
            grovepi.digitalWrite(green_led,1)
            # Send LOW to turn off red LED
            grovepi.digitalWrite(red_led,0)
        else:
            # Send LOW to turn off all LEDs
            grovepi.digitalWrite(green_led,0)
            grovepi.digitalWrite(blue_led,0)
            grovepi.digitalWrite(red_led,0)
        
        # Print data to LCD screen
        grove_rgb_lcd.setText_norefresh("Temp: " + str(temp) + "F\n" + "Humidity: " + str(humidity) + "%")
        
        # Create dataset to load to JSON file
        temp_hum_details = current_time + " : " +  "temp: " + str(temp) + " humidity: " + str(humidity)
            
        # Open the temp_hum JSON file and append the new sensor data
        with open("data.json") as file:
            
            data = json.load(file)
            
            data.append(temp_hum_details)
         
        # Write the updated data to the JSON file     
        with open("data.json", "w") as file:
            
            json.dump(data, file, indent=2)
        
        # Print the light sensor data
        print("sensor_value = %d resistance = %.2f" %(sensor_value,  resistance))
        
        # Sleep for 1 hour in between measurements
        time.sleep(3600)

    except IOError:
        print ("Error")
        # Clear the screen due to error
        grove_rgb_lcd.setText("")
    
    except KeyboardInterrupt:
        # Send LOW to turn off all LEDs when leaving script
        grovepi.digitalWrite(green_led,0)
        grovepi.digitalWrite(blue_led,0)
        grovepi.digitalWrite(red_led,0)
        # Clear and turn off the screen when leaving the script
        grove_rgb_lcd.setText("")
        grove_rgb_lcd.setRGB(0,0,0)
        break
        


